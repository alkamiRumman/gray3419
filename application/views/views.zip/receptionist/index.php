<div class="row">
	<div class="col-md-12">
		<div class="box box-primary">
			<div class="box-body">
				<div class="row">
					<a href="<?= receptionist_url('customers') ?>">
						<div class="col-md-3">
							<div class="small-box bg-orange">
								<div class="inner">
									<h3><?= $totalCustomer ?></h3>
									<p>Total Customer</p>
								</div>
								<div class="icon">
									<i class="fa fa-user-secret"></i>
								</div>
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
