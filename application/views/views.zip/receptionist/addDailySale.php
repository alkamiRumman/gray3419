<div class="modal fade in" id="modal-default" style="display: block;overflow: auto; padding-left: 25px;">
	<div class="modal-dialog modal-lg" style="width: 90%">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="btn btn-danger pull-right" data-dismiss="modal" aria-label="Close">Close
				</button>
				<h4 class="modal-title"><b>Add New Sale</b></h4>
			</div>
			<div class="modal-body">
				<form id="form" action="<?= receptionist_url('saveDailySale') ?>" method="post"
					  enctype="multipart/form-data">
					<div class="row">
						<div class="form-group col-md-4">
							<label for="customerId">Select Existing Customer</label><br>
							<select style="width: 100%" id="customerId" name="customerId"
									class="form-control selectCustomer"></select>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3">
							<label for="customerName"> Name <b class="text-danger">*</b></label>
							<input class="form-control" type="text" name="customerName" id="customerName"
								   placeholder="Enter Document Name" required>
						</div>
						<div class="form-group col-md-3">
							<label for="phone"> Phone </label>
							<input class="form-control" type="text" name="phone" id="phone"
								   placeholder="Enter Phone Number">
						</div>
						<div class="form-group col-md-3">
							<label for="email"> Email </label>
							<input class="form-control" type="email" name="email" id="email"
								   placeholder="Enter Phone Number">
						</div>
						<div class="form-group col-md-3">
							<label for="doctorName">Doctor Name</label>
							<select style="width: 100%" id="doctorName" name="doctorName"
									class="form-control selectDoctor"></select>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3">
							<label for="serviceName">Service/Product Name</label>
							<select style="width: 100%" id="serviceName" name="serviceName"
									class="form-control selectService"></select>
						</div>
						<div class="form-group col-md-2">
							<label for="cashPaid">Cash<b class="text-danger">*</b></label>
							<input class="form-control" type="number" step="any" name="cashPaid" id="cashPaid" required>
						</div>
						<div class="form-group col-md-2">
							<label for="visaPaid">Visa<b class="text-danger">*</b></label>
							<input class="form-control" type="number" step="any" name="visaPaid" id="visaPaid" required>
						</div>
						<div class="form-group col-md-2">
							<label for="remainPaid">Remain Paid<b class="text-danger">*</b></label>
							<input class="form-control" type="number" step="any" name="remainPaid" id="remainPaid"
								   required>
						</div>
						<div class="form-group col-md-3">
							<label for="town">Town</label>
							<input class="form-control" type="text" name="town" id="town">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3">
							<label for="referral">Referral </label>
							<input class="form-control" type="text" name="referral" id="referral">
						</div>
						<div class="form-group col-md-6">
							<label for="note">Note</label>
							<textarea class="form-control" name="note" id="note"></textarea>
						</div>
					</div>
					<div class="box-footer">
						<div class="row">
							<div class="form-group col-md-12">
								<button type="submit" class="btn btn-success pull-right">Save</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$(function () {
		function formatCustom(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		function selection(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		function formatCustomServie(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function selectionServicec(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function formatCustomDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		function selectionDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		$(".selectCustomer").select2({
			placeholder: "Select Old Customer",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustom,
			templateSelection: selection,
			ajax: {
				url: '<?= receptionist_url("getCustomerSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		}).on('select2:select', function (event) {
			var data = event.params.data;
			$('#customerName').val(data.customerName);
			$('#phone').val(data.phone);
			$('#email').val(data.email);
		});
		$(".selectService").select2({
			placeholder: "Select Service/Product",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustomServie,
			templateSelection: selectionServicec,
			ajax: {
				url: '<?= receptionist_url("getServiceSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		});
		$(".selectDoctor").select2({
			placeholder: "Select Doctor",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustomDoctor,
			templateSelection: selectionDoctor,
			ajax: {
				url: '<?= receptionist_url("getDoctorSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		})
	});
</script>
