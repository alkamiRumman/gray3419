<div class="modal fade in" id="modal-default" style="display: block;overflow: auto; padding-left: 25px;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="btn btn-danger pull-right" data-dismiss="modal" aria-label="Close">Close
				</button>
				<h4 class="modal-title"><b>Update Appointment Details</b></h4>
			</div>
			<div class="modal-body">
				<form id="formEdit" action="<?= receptionist_url('updateAppointment/' . $data->id) ?>" method="post"
					  enctype="multipart/form-data">
					<div class="row">
						<div class="form-group col-md-4">
							<label for="customerName"> Name <b class="text-danger">*</b></label>
							<input class="form-control" type="text" name="customerName" id="customerName"
								   value="<?= $data->customerName ?>" readonly>
						</div>
						<div class="form-group col-md-4">
							<label for="phone"> Phone <b class="text-danger">*</b></label>
							<input class="form-control" type="text" name="phone" id="phone"
								   value="<?= $data->phone ?>" readonly>
						</div>
						<div class="form-group col-md-4">
							<label for="email"> Email <b class="text-danger">*</b></label>
							<input class="form-control" type="email" name="email" id="email"
								   value="<?= $data->email ?>" readonly>
						</div>
						<div class="form-group col-md-3">
							<label for="date">Date<b class="text-danger">*</b></label>
							<div class="input-group date">
								<div class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</div>
								<input type="text" class="form-control pull-right" name="date"
									   id="date" value="<?= date('d M Y', strtotime($data->date)) ?>" required>
							</div>
						</div>
						<div class="form-group col-md-4">
							<label for="doctorName">Doctor Name</label>
							<select style="width: 100%" id="doctorName" name="doctorName"
									class="form-control selectDoctor"></select>
							<p class="text-danger">Leave it blank if no changes!!</p>
						</div>
						<div class="form-group col-md-4">
							<label for="serviceName">Service/Product Name</label>
							<select style="width: 100%" id="serviceName" name="serviceName"
									class="form-control selectService"></select>
							<p class="text-danger">Leave it blank if no changes!!</p>
						</div>
						<div class="form-group col-md-6">
							<label for="note">Note</label>
							<textarea class="form-control" name="note" id="note"><?= $data->note ?></textarea>
						</div>
					</div>
					<div class="box-footer">
						<div class="row">
							<div class="form-group col-md-12">
								<button type="submit" class="btn btn-primary pull-right">Update</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$('#date').datepicker({
		autoclose: true,
		todayHighlight: true,
		startDate: '+1d',
		format: 'dd M yyyy'
	});
	$(function () {
		function formatCustomServie(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function selectionServicec(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function formatCustomDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		function selectionDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		$(".selectService").select2({
			dropdownParent: $('#remoteModal1'),
			placeholder: "Select Service if change",
			templateResult: formatCustomServie,
			templateSelection: selectionServicec,
			ajax: {
				url: '<?= receptionist_url("getServiceSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		});
		$(".selectDoctor").select2({
			dropdownParent: $('#remoteModal1'),
			placeholder: "Select Doctor if change",
			templateResult: formatCustomDoctor,
			templateSelection: selectionDoctor,
			ajax: {
				url: '<?= receptionist_url("getDoctorSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		});
	});
</script>

