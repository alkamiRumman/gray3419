<div class="row">
	<div class="col-md-6">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title"><b>Client Search </b></h3>
			</div>
			<div class="box-body">
				<div class="row">
					<div class="form-group col-md-5">
						<div class="row">
							<div class="col-md-12">
								<label for="customerId">Select Customer</label><br>
								<select style="width: 100%;" id="customerId" name="customerId"
										class="form-control selectCustomer"></select>
							</div>
						</div>
						<div class="row" style="margin-top: 10px">
							<div class="col-md-12">
								<label for="doctorName">Select Doctor</label><br>
								<select style="width: 100%" id="doctorName" name="doctorName"
										class="form-control selectDoctor"></select>
							</div>
						</div>
						<div class="row" style="margin-top: 10px">
							<div class="col-md-12">
								<label for="serviceName">Select Service/Product</label><br>
								<select style="width: 100%" id="serviceName" name="serviceName"
										class="form-control selectService"></select>
							</div>
						</div>
					</div>
					<div class="col-md-7" style="margin-top: 30px">
						<table class="table">
							<tr>
								<th>Name</th>
								<td id="name" class="text-left">—</td>
							</tr>
							<tr>
								<th>Phone</th>
								<td id="phone" class="text-left">—</td>
							</tr>
							<tr>
								<th>Email</th>
								<td id="email" class="text-left">—</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
			<div class="box-footer">
				<div class="row text-center">
					<div class="form-group col-md-12">
						<button type="button" id="search" class="btn btn-info">Search</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title"><b>Sales Search</b></h3>
			</div>
			<div class="box-body">
				<div class="row" id="dateSelect">
					<div class="form-group col-md-2"></div>
					<div class="form-group col-md-4">
						<div class="input-group date">
							<div class="input-group-addon">
								<i class="fa fa-calendar"></i>
							</div>
							<input type="text" class="form-control pull-right" name="start_date"
								   id="start_date" placeholder="Start Date" required>
						</div>
					</div>
					<div class="form-group col-md-4">
						<div class="input-group date">
							<div class="input-group-addon">
								<i class="fa fa-calendar"></i>
							</div>
							<input type="text" class="form-control pull-right" name="end_date"
								   id="end_date" placeholder="End Date" required>
						</div>
					</div>
					<div class="form-group col-md-2"></div>
				</div>
			</div>
			<div class="box-footer">
				<div class="row text-center">
					<div class="form-group col-md-12">
						<button type="button" id="searchDate" class="btn btn-info">Search</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="box box-info">
			<div class="box-header with-border">
				<h3 class="box-title"><b>Search Result</b></h3>
			</div>
			<div class="box-body">
				<div class="table-responsive">
					<table id="reportTable"
						   class="table table-striped table-bordered serverSide-table dtr-inline text-bold text-center"
						   style="width: 100% !important;">
						<thead>
						<tr>
							<th>Date</th>
							<th style="padding: 10px 50px">Name</th>
							<th>Doctor name</th>
							<th>Service/ Product name</th>
							<th style="padding: 10px 90px">Notes</th>
							<th>Cash</th>
							<th>Visa</th>
							<th>Debit</th>
							<th>Town</th>
							<th>Referral</th>
							<th>Create By</th>
							<th>Create At</th>
						</tr>
						</thead>
						<tbody>
						</tbody>
						<tfoot>
						<th colspan="5" class="text-right">Total</th>
						<th></th>
						<th></th>
						<th></th>
						<th colspan="4"></th>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
	table.dataTable tbody td {
		vertical-align: middle;
		padding-left: 0;
		padding-right: 0;
		margin-left: 0;
		margin-right: 0;
		margin-top: 0;
		margin-bottom: 0;
		padding-top: 0;
		padding-bottom: 0;
	}

	#reportTable {
		border-collapse: collapse;
	}
</style>
<script>
	$("#start_date, #end_date").datepicker({
		changeMonth: true,
		changeYear: true,
		maxDate: 0,
		dateFormat: 'dd M yy'
	});
	var Table = [];
	$(function () {
		function formatCustomServie(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function selectionServicec(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function formatCustomDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		function selectionDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		function formatCustom(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		function selection(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		$(".selectService").select2({
			placeholder: "Select Service/Product",
			templateResult: formatCustomServie,
			templateSelection: selectionServicec,
			ajax: {
				url: '<?= receptionist_url("getServiceSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		}).on('select2:select', function (event) {
			$('#name').closest('td').text('');
			$('#phone').closest('td').text('');
			$('#email').closest('td').text('');
		});
		$(".selectDoctor").select2({
			placeholder: "Select Doctor",
			templateResult: formatCustomDoctor,
			templateSelection: selectionDoctor,
			ajax: {
				url: '<?= receptionist_url("getDoctorSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		}).on('select2:select', function (event) {
			$('#name').closest('td').text('');
			$('#phone').closest('td').text('');
			$('#email').closest('td').text('');
		});

		$(".selectCustomer").select2({
			placeholder: "Select Customer",
			templateResult: formatCustom,
			templateSelection: selection,
			ajax: {
				url: '<?= receptionist_url("getCustomerSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		}).on('select2:select', function (event) {
			var data = event.params.data;
			$('#name').closest('td').text(data.customerName);
			$('#phone').closest('td').text(data.phone);
			$('#email').closest('td').text(data.email);
		});
	});
	$(".selectCustomer").on('change', function () {
		$(".selectService").empty();
		$(".selectDoctor").empty();
		if ($.isEmptyObject(Table) == false) {
			Table.destroy();
			$('#reportTable tr td').empty();
			$('#reportTable tfoot tr th').empty();
		}
	})
	$(".selectService").on('change', function () {
		$(".selectCustomer").empty();
		$(".selectDoctor").empty();
		if ($.isEmptyObject(Table) == false) {
			Table.destroy();
			$('#reportTable tr td').empty();
			$('#reportTable tfoot tr th').empty();
		}
	})
	$(".selectDoctor").on('change', function () {
		$(".selectCustomer").empty();
		$(".selectService").empty();
		if ($.isEmptyObject(Table) == false) {
			Table.destroy();
			$('#reportTable tr td').empty();
			$('#reportTable tfoot tr th').empty();
		}
	})
	$('#search').on('click', function () {
		$('#start_date').val('');
		$('#end_date').val('');
		var customerId = $('#customerId').val();
		var serviceId = $('#serviceName').val();
		var doctorId = $('#doctorName').val();
		if (customerId != null) {
			Table = $('.serverSide-table').DataTable({
				serverSide: true,
				order: [[0, "ASC"]],
				// destroy: true,
				stateSave: true,
				"columnDefs": [
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY');
						}, "targets": 0
					},
					{
						"render": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}, "targets": [5, 6, 7]
					},
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY hh:mm:ss A');
						}, "targets": 11
					}
				],
				'aoColumns': [{mData: "date"}, {mData: "customerName"}, {mData: "doctorName"}, {mData: "serviceName"}, {mData: "note"},
					{mData: "cashPaid"}, {mData: "visaPaid"}, {mData: "remainPaid"}, {mData: "town"}, {mData: "referral"}, {mData: "name"},
					{mData: "createAt"}],
				"aLengthMenu": [[25, 50, 100, 200, 500, 1000], [25, 50, 100, 200, 500, 1000]],
				"iDisplayLength": 25,
				'bProcessing': true,
				"language": {
					processing: '<div><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading Please Wait...</span></div>'
				},
				'bServerSide': true,
				'sAjaxSource': '<?= receptionist_url('getDaileSaleClientSearch/') ?>' + customerId,
				'fnServerData': function (sSource, aoData, fnCallback) {
					$.ajax({
						'dataType': 'json',
						'type': 'POST',
						'url': sSource,
						'data': aoData,
						'success': function (d, e, f) {
							console.log(d);
							fnCallback(d, e, f);
						},
						error: function (jqXHR, textStatus, errorThrown) {
							console.log(jqXHR);
							if (jqXHR.jqXHRstatusText)
								alert(jqXHR.jqXHRstatusText);
						}
					});
				},
				"fnFooterCallback": function (row, data, start, end, display) {
					var api = this.api(), data;
					var intVal = function (i) {
						return typeof i === 'string' ?
							i.replace(/[\$,]/g, '') * 1 :
							typeof i === 'number' ?
								i : 0;
					};

					// Total over all pages
					totalCahs = api
						.column(5)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalVisa = api
						.column(6)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalDebt = api
						.column(7)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);


					// Update footer
					$(api.column(5).footer()).html(
						'£' + totalCahs.toFixed(2));
					$(api.column(6).footer()).html(
						'£' + totalVisa.toFixed(2));
					$(api.column(7).footer()).html(
						'£' + totalDebt.toFixed(2));

				},
				select: {
					style: 'multi',
					selector: 'td:first-child'
				},
				dom: '<"top"B<"pull-right"f>>irtlp',
				// dom: 'lfrtip',
				buttons: [
					'copy', {
						extend: 'csv',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'excel',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'colvis',
						text: 'Column Visibility',
						collectionLayout: 'two-column'
					}
				]
			});
		} else if (serviceId != null) {
			Table = $('.serverSide-table').DataTable({
				serverSide: true,
				order: [[0, "ASC"]],
				// destroy: true,
				stateSave: true,
				"columnDefs": [
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY');
						}, "targets": 0
					},
					{
						"render": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}, "targets": [5, 6, 7]
					},
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY hh:mm:ss A');
						}, "targets": 11
					}
				],
				'aoColumns': [{mData: "date"}, {mData: "customerName"}, {mData: "doctorName"}, {mData: "serviceName"}, {mData: "note"},
					{mData: "cashPaid"}, {mData: "visaPaid"}, {mData: "remainPaid"}, {mData: "town"}, {mData: "referral"}, {mData: "name"},
					{mData: "createAt"}],
				"aLengthMenu": [[25, 50, 100, 200, 500, 1000], [25, 50, 100, 200, 500, 1000]],
				"iDisplayLength": 25,
				'bProcessing': true,
				"language": {
					processing: '<div><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading Please Wait...</span></div>'
				},
				'bServerSide': true,
				'sAjaxSource': '<?= receptionist_url('getDaileSaleServiceSearch/') ?>' + serviceId,
				'fnServerData': function (sSource, aoData, fnCallback) {
					$.ajax({
						'dataType': 'json',
						'type': 'POST',
						'url': sSource,
						'data': aoData,
						'success': function (d, e, f) {
							console.log(d);
							fnCallback(d, e, f);
						},
						error: function (jqXHR, textStatus, errorThrown) {
							console.log(jqXHR);
							if (jqXHR.jqXHRstatusText)
								alert(jqXHR.jqXHRstatusText);
						}
					});
				},
				"fnFooterCallback": function (row, data, start, end, display) {
					var api = this.api(), data;
					var intVal = function (i) {
						return typeof i === 'string' ?
							i.replace(/[\$,]/g, '') * 1 :
							typeof i === 'number' ?
								i : 0;
					};

					// Total over all pages
					totalCahs = api
						.column(5)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalVisa = api
						.column(6)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalDebt = api
						.column(7)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);


					// Update footer
					$(api.column(5).footer()).html(
						'£' + totalCahs.toFixed(2));
					$(api.column(6).footer()).html(
						'£' + totalVisa.toFixed(2));
					$(api.column(7).footer()).html(
						'£' + totalDebt.toFixed(2));

				},
				select: {
					style: 'multi',
					selector: 'td:first-child'
				},
				dom: '<"top"B<"pull-right"f>>irtlp',
				// dom: 'lfrtip',
				buttons: [
					'copy', {
						extend: 'csv',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'excel',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'colvis',
						text: 'Column Visibility',
						collectionLayout: 'two-column'
					}
				]
			});
		} else if (doctorId != null) {
			Table = $('.serverSide-table').DataTable({
				serverSide: true,
				order: [[0, "ASC"]],
				// destroy: true,
				stateSave: true,
				"columnDefs": [
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY');
						}, "targets": 0
					},
					{
						"render": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}, "targets": [5, 6, 7]
					},
					{
						"render": function (data, type, row) {
							return moment(data).format('DD MMM YYYY hh:mm:ss A');
						}, "targets": 11
					}
				],
				'aoColumns': [{mData: "date"}, {mData: "customerName"}, {mData: "doctorName"}, {mData: "serviceName"}, {mData: "note"},
					{mData: "cashPaid"}, {mData: "visaPaid"}, {mData: "remainPaid"}, {mData: "town"}, {mData: "referral"}, {mData: "name"},
					{mData: "createAt"}],
				"aLengthMenu": [[25, 50, 100, 200, 500, 1000], [25, 50, 100, 200, 500, 1000]],
				"iDisplayLength": 25,
				'bProcessing': true,
				"language": {
					processing: '<div><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading Please Wait...</span></div>'
				},
				'bServerSide': true,
				'sAjaxSource': '<?= receptionist_url('getDaileSaleDoctorSearch/') ?>' + doctorId,
				'fnServerData': function (sSource, aoData, fnCallback) {
					$.ajax({
						'dataType': 'json',
						'type': 'POST',
						'url': sSource,
						'data': aoData,
						'success': function (d, e, f) {
							console.log(d);
							fnCallback(d, e, f);
						},
						error: function (jqXHR, textStatus, errorThrown) {
							console.log(jqXHR);
							if (jqXHR.jqXHRstatusText)
								alert(jqXHR.jqXHRstatusText);
						}
					});
				},
				"fnFooterCallback": function (row, data, start, end, display) {
					var api = this.api(), data;
					var intVal = function (i) {
						return typeof i === 'string' ?
							i.replace(/[\$,]/g, '') * 1 :
							typeof i === 'number' ?
								i : 0;
					};

					// Total over all pages
					totalCahs = api
						.column(5)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalVisa = api
						.column(6)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalDebt = api
						.column(7)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);


					// Update footer
					$(api.column(5).footer()).html(
						'£' + totalCahs.toFixed(2));
					$(api.column(6).footer()).html(
						'£' + totalVisa.toFixed(2));
					$(api.column(7).footer()).html(
						'£' + totalDebt.toFixed(2));

				},
				select: {
					style: 'multi',
					selector: 'td:first-child'
				},
				dom: '<"top"B<"pull-right"f>>irtlp',
				// dom: 'lfrtip',
				buttons: [
					'copy', {
						extend: 'csv',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'excel',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'colvis',
						text: 'Column Visibility',
						collectionLayout: 'two-column'
					}
				]
			});
		} else {
			toastr.warning('Select any fields first!!');
		}
	});
	$('#searchDate').on('click', function () {
		$('#name').closest('td').text('');
		$('#phone').closest('td').text('');
		$('#email').closest('td').text('');
		$(".selectCustomer").empty();
		$(".selectService").empty();
		$(".selectDoctor").empty();
		var startDate = $('#start_date').val();
		var endDate = $('#end_date').val();
		if (startDate == '' || endDate == '') {
			toastr.warning('Select Date Range Fist!');
		} else {
			if ($.isEmptyObject(Table) == false) {
				Table.destroy();
				$('#reportTable tr td').empty();
				$('#reportTable tfoot tr th').empty();
			}
			Table = $('.serverSide-table').DataTable({
				"order": [[0, "desc"]],
				// scrollCollapse: true,
				dom: '<"top"B<"pull-right"f>>irtlp',
				buttons: [
					'copy', {
						extend: 'csv',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'excel',
						exportOptions: {
							columns: ':visible:not(:last-child)'
						}
					}, {
						extend: 'colvis',
						text: 'Column Visibility',
						collectionLayout: 'two-column'
					}
				],
				"ajax": {
					data: {start_date: startDate, end_date: endDate},
					url: "<?= receptionist_url('getDaileSaleClientSearchByDate') ?>",
					type: 'POST'
				},
				"aLengthMenu": [[25, 50, 100, 200, 500, -1], [25, 50, 100, 200, 500, 'All']],
				"aoColumns": [
					{
						"mRender": function (data, type, row) {
							return moment(data).format('DD MMM YYYY');
						}
					}, null, null, null, null,
					{
						"mRender": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}
					}, {
						"mRender": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}
					}, {
						"mRender": function (data, type, row) {
							if (data > 0) {
								return '£' + data;
							} else {
								return '<span class="text-center">—</span>';
							}
						}
					}, null, null, null, {
						"mRender": function (data, type, row) {
							return moment(data).format('DD MMM YYYY hh:mm:ss A');
						}
					}],
				"fnFooterCallback": function (row, data, start, end, display) {
					var api = this.api(), data;
					var intVal = function (i) {
						return typeof i === 'string' ?
							i.replace(/[\$,]/g, '') * 1 :
							typeof i === 'number' ?
								i : 0;
					};

					// Total over all pages
					totalCahs = api
						.column(5)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalVisa = api
						.column(6)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);
					totalDebt = api
						.column(7)
						.data()
						.reduce(function (a, b) {
							return intVal(a) + intVal(b);
						}, 0);


					// Update footer
					$(api.column(5).footer()).html(
						'£' + totalCahs.toFixed(2));
					$(api.column(6).footer()).html(
						'£' + totalVisa.toFixed(2));
					$(api.column(7).footer()).html(
						'£' + totalDebt.toFixed(2));

				},
			});
		}
	});
</script>
