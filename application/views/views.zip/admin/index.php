<?php

/**
 * @property Admin_model $admin
 */
class Admin extends MY_Controller
{
	public $path = '/admin';

	function __construct()
	{
		parent::__construct();
		$this->ifNotLogin();
		$this->ifNotAdmin();
		$this->load->model('Admin_model', 'admin');
	}

	function index()
	{
		$this->data['title'] = 'Dashboard';
		$this->makeView('/index');
	}

	function charges()
	{
		$this->data['title'] = 'Charges';
		$this->makeView('/charges');
	}

	function addCharges()
	{
		$this->data['title'] = 'Add Charges';
		$this->popupView('/addCharges');
	}

	function saveCharges()
	{
//		return dnp($_POST);
		$arr['courier'] = $this->input->post('courier');
		$arr['service'] = $this->input->post('service');
		$arr['data_100'] = $this->input->post('data_100');
		$arr['data_250'] = $this->input->post('data_250');
		$arr['data_500'] = $this->input->post('data_500');
		$arr['data_750'] = $this->input->post('data_750');
		$arr['data_1000'] = $this->input->post('data_1000');
		$arr['data_2000'] = $this->input->post('data_2000');
		$arr['data_3000'] = $this->input->post('data_3000');
		$arr['data_5000'] = $this->input->post('data_5000');
		$arr['data_10000'] = $this->input->post('data_10000');
		$arr['data_15000'] = $this->input->post('data_15000');
		$arr['data_17000'] = $this->input->post('data_17000');
		$arr['data_30000'] = $this->input->post('data_30000');
		$this->admin->saveCharges($arr);
		$this->session->set_flashdata('success', 'Charge Added Successfully.');
		redirect('admin/charges');
	}

	function getCharge()
	{
		$action = '<a href="javascript:void(0);" onclick="loadPopup(\'' . base_url('admin/editCharge/$1') . '\')" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
			<a href="deleteCharge/$1' . '" onclick="return confirm(\'Are Your sure?\')" class="btn btn-sm btn-danger">
            <i class="fa fa-trash"></a>';
		$this->datatables->select('id, courier, service, data_100, data_250, data_500, data_750, data_1000, data_2000, data_3000, 
		data_5000, data_10000, data_15000, data_17000, data_30000, updateAt');
		$this->datatables->from(TABLE_CHARGES);
		$this->datatables->order_by('id desc');
		$this->datatables->addColumn('actions', $action, 'id');
		$this->datatables->generate();
	}

	function editCharge($id)
	{
		$this->data['data'] = $this->admin->getChargesById($id);
		$this->popupView('/editCharge');
	}

	function updateCharge($id)
	{
		$arr['courier'] = $this->input->post('courier');
		$arr['service'] = $this->input->post('service');
		$arr['data_100'] = $this->input->post('data_100');
		$arr['data_250'] = $this->input->post('data_250');
		$arr['data_500'] = $this->input->post('data_500');
		$arr['data_750'] = $this->input->post('data_750');
		$arr['data_1000'] = $this->input->post('data_1000');
		$arr['data_2000'] = $this->input->post('data_2000');
		$arr['data_3000'] = $this->input->post('data_3000');
		$arr['data_5000'] = $this->input->post('data_5000');
		$arr['data_10000'] = $this->input->post('data_10000');
		$arr['data_15000'] = $this->input->post('data_15000');
		$arr['data_17000'] = $this->input->post('data_17000');
		$arr['data_30000'] = $this->input->post('data_30000');
		$arr['updateAt'] = date('Y-m-d H:i:s');
		$this->admin->updateCharges($arr, $id);
		$this->session->set_flashdata('success', 'Charge Updated Successfully.');
		redirect('admin/charges');
	}

	function deleteCharge($id)
	{
		$this->admin->deleteCharges($id);
		$this->session->set_flashdata('success', 'Charge Successfully Removed..');
		redirect('admin/charges');
	}

	function items()
	{
		$this->data['title'] = 'Items';
		$this->makeView('/items');
	}

	function addItems()
	{
		$this->data['title'] = 'Add Items';
		$this->popupView('/addItems');
	}

	function saveItems()
	{
//		return dnp($_POST);
		$arr['items'] = $this->input->post('items');
		$arr['sku'] = $this->input->post('sku');
		$arr['itemsNumber'] = $this->input->post('itemsNumber');
		$arr['parcels'] = $this->input->post('parcels');
		$arr['length'] = $this->input->post('length');
		$arr['width'] = $this->input->post('width');
		$arr['height'] = $this->input->post('height');
		$arr['weight'] = $this->input->post('weight');
		$arr['className'] = $this->input->post('className');
		$arr['maxPerParcel'] = $this->input->post('maxPerParcel');
		$arr['weightResult'] = $this->input->post('weightResult');
		$arr['updateAt'] = date('Y-m-d H:i:s');
		$this->admin->saveItems($arr);
		$this->session->set_flashdata('success', 'Item Added Successfully.');
		redirect('admin/items');
	}

	function getItem()
	{
		$action = '<a href="javascript:void(0);" onclick="loadPopup(\'' . base_url('admin/editItem/$1') . '\')" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
			<a href="deleteItem/$1' . '" onclick="return confirm(\'Are Your sure?\')" class="btn btn-sm btn-danger">
            <i class="fa fa-trash"></a>';
		$this->datatables->select('id, items, sku, itemsNumber, parcels, length, width, height, weight, className, 
		maxPerParcel, weightResult, createAt, updateAt');
		$this->datatables->from(TABLE_ITEMS);
		$this->datatables->order_by('id desc');
		$this->datatables->addColumn('actions', $action, 'id');
		$this->datatables->generate();
	}

	function editItem($id)
	{
		$this->data['data'] = $this->admin->getItemsById($id);
		$this->popupView('/editItem');
	}

	function updateItem($id)
	{
		$arr['items'] = $this->input->post('items');
		$arr['sku'] = $this->input->post('sku');
		$arr['itemsNumber'] = $this->input->post('itemsNumber');
		$arr['parcels'] = $this->input->post('parcels');
		$arr['length'] = $this->input->post('length');
		$arr['width'] = $this->input->post('width');
		$arr['height'] = $this->input->post('height');
		$arr['weight'] = $this->input->post('weight');
		$arr['className'] = $this->input->post('data_3000');
		$arr['maxPerParcel'] = $this->input->post('maxPerParcel');
		$arr['weightResult'] = $this->input->post('weightResult');
		$this->admin->updateItems($arr, $id);
		$this->session->set_flashdata('success', 'Item Updated Successfully.');
		redirect('admin/items');
	}

	function deleteItem($id)
	{
		$this->admin->deleteItems($id);
		$this->session->set_flashdata('success', 'Item Successfully Removed..');
		redirect('admin/items');
	}

	function importOrder()
	{
		$this->data['title'] = 'Import Order';
		$this->makeView('/importOrder');
	}

	function uploadOrder()
	{
//		return dnp($_FILES);
		if (isset($_FILES["file"]["name"])) {
			$invoice['fileName'] = $_FILES["file"]["name"];

//			$this->admin->saveInvoice($invoice);
			$invoiceId = $this->db->insert_id();

			$path = $_FILES["file"]["tmp_name"];
			$inputFileType = PHPExcel_IOFactory::identify($path);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objReader->setReadDataOnly(true);
			$objPHPExcel = $objReader->load($path);
//				return dnp($objPHPExcel->getWorksheetIterator());
//				$object = PHPExcel_IOFactory::load($path);
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
//					return dnp($highestRow);
//					if ($highestColumn === 'N') {
				for ($row = 2; $row <= $highestRow; $row++) {
					$selro_order_id = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$order_id = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
					$order_dateCell = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
					if ($order_dateCell) {
						$order_date = date_format(date_create($order_dateCell), 'Y-m-d');
					} else {
						$order_date = '';
					}
					$expected_dispatch_dateCell = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
					if ($expected_dispatch_dateCell) {
						$expected_dispatch_date = date_format(date_create($expected_dispatch_dateCell), 'Y-m-d');
					} else {
						$expected_dispatch_date = '';
					}
					$channel = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
					$channel_name = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
					$site = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
					$title = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
					$variation = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
					$asin = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
					$sku = $worksheet->getCellByColumnAndRow(10, $row)->getValue();
					$upc = $worksheet->getCellByColumnAndRow(11, $row)->getValue();
					$order_item_id = $worksheet->getCellByColumnAndRow(12, $row)->getValue();
					$order_status = $worksheet->getCellByColumnAndRow(13, $row)->getValue();
					$weight = $worksheet->getCellByColumnAndRow(14, $row)->getValue();
					$weight_unit = $worksheet->getCellByColumnAndRow(15, $row)->getValue();
					$item_price = $worksheet->getCellByColumnAndRow(16, $row)->getValue();
					$quantity_purchased = $worksheet->getCellByColumnAndRow(17, $row)->getValue();
					$sub_total = $worksheet->getCellByColumnAndRow(18, $row)->getValue();
					$shipping_cost = $worksheet->getCellByColumnAndRow(19, $row)->getValue();
					$line_item_total = $worksheet->getCellByColumnAndRow(20, $row)->getValue();
					$order_total = $worksheet->getCellByColumnAndRow(21, $row)->getValue();
					$buyer_email = $worksheet->getCellByColumnAndRow(22, $row)->getValue();
					$buyer_name = $worksheet->getCellByColumnAndRow(23, $row)->getValue();
					$ship_address_1 = $worksheet->getCellByColumnAndRow(24, $row)->getValue();
					$ship_address_2 = $worksheet->getCellByColumnAndRow(25, $row)->getValue();
					$ship_address_3 = $worksheet->getCellByColumnAndRow(26, $row)->getValue();
					$ship_city = $worksheet->getCellByColumnAndRow(27, $row)->getValue();
					$ship_state = $worksheet->getCellByColumnAndRow(28, $row)->getValue();
					$ship_country = $worksheet->getCellByColumnAndRow(29, $row)->getValue();
					$ship_country_code = $worksheet->getCellByColumnAndRow(30, $row)->getValue();
					$ship_postalcode = $worksheet->getCellByColumnAndRow(31, $row)->getValue();
					$shipping_discount = $worksheet->getCellByColumnAndRow(32, $row)->getValue();
					$shipping_tax = $worksheet->getCellByColumnAndRow(33, $row)->getValue();
					$item_tax = $worksheet->getCellByColumnAndRow(34, $row)->getValue();
					$currency_code = $worksheet->getCellByColumnAndRow(35, $row)->getValue();
					$payment_status = $worksheet->getCellByColumnAndRow(36, $row)->getValue();
					$payment_dateCell = $worksheet->getCellByColumnAndRow(37, $row)->getValue();
					if ($payment_dateCell) {
						$payment_date = date_format(date_create($payment_dateCell), 'Y-m-d');
					} else {
						$payment_date = '';
					}
					$payments_transaction_id = $worksheet->getCellByColumnAndRow(38, $row)->getValue();
					$shipped_date = $worksheet->getCellByColumnAndRow(39, $row)->getValue();
					$shipping_method = $worksheet->getCellByColumnAndRow(40, $row)->getValue();
					$shipping_carrier = $worksheet->getCellByColumnAndRow(41, $row)->getValue();
					$tel_no = $worksheet->getCellByColumnAndRow(42, $row)->getValue();
					$tracking_id = $worksheet->getCellByColumnAndRow(43, $row)->getValue();
					$ean = $worksheet->getCellByColumnAndRow(44, $row)->getValue();
					$order_customisation = $worksheet->getCellByColumnAndRow(45, $row)->getValue();
					$payment_method = $worksheet->getCellByColumnAndRow(46, $row)->getValue();

					$calWeight = $weight * 1000;

					$courier = count(explode('|', $shipping_method)) > 1 ? explode('|', $shipping_method)[0] : $shipping_carrier;

					$weightBandPostage_BK = $calWeight <= 100 ? 100 : ($calWeight <= 250 ? 250 : ($calWeight <= 500 ? 500 : ($calWeight <= 750 ? 750 :
						($calWeight <= 1000 ? 1000 : ($calWeight <= 2000 ? 2000 : ($calWeight <= 3000 ? 3000 : ($calWeight <= 5000 ? 5000 :
							($calWeight <= 10000 ? 10000 : ($calWeight <= 15000 ? 15000 : ($calWeight <= 17000 ? 17000 : ($calWeight <= 30000 ? 30000 : 0)))))))))));
					$chargeVariable = 'data_' . $weightBandPostage_BK;
					$minParcelPerSKU_AY = $this->admin->getItemsBySKU($sku) ? $this->admin->getItemsBySKU($sku)->parcels : 0;
					$maxParcel_AZ = $this->admin->getItemsBySKU($sku) ? $this->admin->getItemsBySKU($sku)->maxPerParcel : 0;
					$parcel_BA = ceil($quantity_purchased / $maxParcel_AZ) * $minParcelPerSKU_AY;

					$service = count(explode('|', $shipping_method)) > 1 ? explode('|', $shipping_method)[1] . $shipping_carrier = 'parcelforce' && $parcel_BA >= 2 ? '+' : '' :
						explode('|', $shipping_method)[0] . $shipping_carrier = 'parcelforce' && $parcel_BA >= 2 ? '+' : '';

					$postage_BU = $this->admin->getChargeByService($service)->$chargeVariable * $parcel_BA;
					$postalCode = explode(' ', $ship_postalcode)[0] ? explode(' ', $ship_postalcode)[0] : '';
					$ofaCharge_BX = $courier == 'Hermes' ? ($this->admin->getHermesChargeByPostCode($postalCode) ? $this->admin->getHermesChargeByPostCode($postalCode)->charge : 0) * $parcel_BA : ($courier == 'Yodel' ?
						($this->admin->getYodelChargeByPostCode($postalCode) ? $this->admin->getYodelChargeByPostCode($postalCode)->charge : 0) * $parcel_BA : ($courier == 'XPECT 48 XL POD 2VLP' ?
							($this->admin->getXpect48ChargeByPostCode($postalCode) ? $this->admin->getXpect48ChargeByPostCode($postalCode)->charge : 0) + $postage_BU : 0));
					$length_BB = $this->admin->getItemsBySKU($sku) ? $this->admin->getItemsBySKU($sku)->length : 0;
					$weight_BC = $this->admin->getItemsBySKU($sku) ? $this->admin->getItemsBySKU($sku)->width : 0;
					$pfSurge_BW = $service == 'express24/SND' || $service == 'express48/SUP' || $service == 'express24/SND+' || $service == 'express48/SUP+' ? ($length_BB >= 100 ? 7.45 :
						($length_BB >= 70 && $weight_BC >= 70 ? 7.45 : 0)) : 0;
					$postageCost_BY = $ofaCharge_BX > 0 ? $ofaCharge_BX : $postage_BU;
					$totalPostageCost_BZ = $postageCost_BY > 0 ? ($pfSurge_BW > 0 ? $pfSurge_BW + $postageCost_BY : $postageCost_BY) : 0;

					$fuelSurge_CA = $courier == 'Royal Mail' ? ($postageCost_BY * 0.02) : ($courier == 'Hermes' ? ($postageCost_BY * 0.025) :
						($courier == 'Yodel' ? ($postageCost_BY * 0.055) : ($courier == 'parcelforce' ? ($postageCost_BY * 0.0975) : 0)));
					$londonCon_CB = $courier == 'parcelforce' ? ($this->admin->getCongestionChargeByPostCode($postalCode) ? $this->admin->getCongestionChargeByPostCode($postalCode)->charge : 0) * $parcel_BA : 0;

					$weightBandHandling_BM = $calWeight <= 15000 ? 15000 : ($calWeight <= 23000 ? 23000 : ($calWeight <= 30000 ? 30000 : 0));
					$handlingFirst_CC = $weightBandHandling_BM == 15000 ? (1.10 * $parcel_BA) : ($weightBandHandling_BM == 23000 ? (1.5 * $parcel_BA) :
						($weightBandHandling_BM == 30000 ? (1.99 * $parcel_BA) : 0));

					$items_AW = $quantity_purchased > 0 ? (($this->admin->getItemsBySKU($sku) ? $this->admin->getItemsBySKU($sku)->itemsNumber : 0) * $quantity_purchased) : 0;
//					$totalItem_AX = $sku != '' ? ($this->admin->getTotalItems_AXByTrackingId($tracking_id, $invoiceId) ? $this->admin->getTotalItems_AXByTrackingId($tracking_id, $invoiceId)->items_AW : 0) : 0;

					$data[] = array(
						'invoiceId' => $invoiceId,
						'selro_order_id' => $selro_order_id,
						'order_id' => $order_id,
						'order_date' => $order_date,
						'expected_dispatch_date' => $expected_dispatch_date,
						'channel' => $channel,
						'channel_name' => $channel_name,
						'site' => $site,
						'title' => $title,
						'variation' => $variation,
						'asin' => $asin,
						'sku' => $sku,
						'upc' => $upc,
						'order_item_id' => $order_item_id,
						'order_status' => $order_status,
						'weight' => $weight,
						'weight_unit' => $weight_unit,
						'item_price' => $item_price,
						'quantity_purchased' => $quantity_purchased,
						'sub_total' => $sub_total,
						'shipping_cost' => $shipping_cost,
						'line_item_total' => $line_item_total,
						'order_total' => $order_total,
						'buyer_email' => $buyer_email,
						'buyer_name' => $buyer_name,
						'ship_address_1' => $ship_address_1,
						'ship_address_2' => $ship_address_2,
						'ship_address_3' => $ship_address_3,
						'ship_city' => $ship_city,
						'ship_state' => $ship_state,
						'ship_country' => $ship_country,
						'ship_country_code' => $ship_country_code,
						'ship_postalcode' => $ship_postalcode,
						'shipping_discount' => $shipping_discount,
						'shipping_tax' => $shipping_tax,
						'item_tax' => $item_tax,
						'currency_code' => $currency_code,
						'payment_status' => $payment_status,
						'payment_date' => $payment_date,
						'payments_transaction_id' => $payments_transaction_id,
						'shipped_date' => $shipped_date,
						'shipping_method' => $shipping_method,
						'shipping_carrier' => $shipping_carrier,
						'tel_no' => $tel_no,
						'tracking_id' => $tracking_id,
						'ean' => $ean,
						'order_customisation' => $order_customisation,
						'payment_method' => $payment_method,

						'L' => $length_BB,
						'W' => $weight_BC,
						'postage' => $postage_BU,
						'pfSurge' => $pfSurge_BW,
						'ofaCharge' => $ofaCharge_BX,
						'minParcelPerSKU' => $minParcelPerSKU_AY,
						'maxParcel' => $maxParcel_AZ,
						'parcel' => $parcel_BA,
						'postageCost' => $postageCost_BY,
						'totalPostageCost' => $totalPostageCost_BZ,

						'fuelSurge' => $fuelSurge_CA,
						'londonCon' => $londonCon_CB,

						'handlingFirst' => $handlingFirst_CC,
						'items_AW' => $items_AW,
//						'totalItem_AX' => $totalItem_AX,

					);
				}
//				return dnp(count($data));
				for ($i = 0; $i < count($data); $i++) {
//					return dnp($data[$i]['sku']);
					$totalItem_AX = 0;
					if (!empty($data[$i]['sku'])) {
						if ($data[$i]['tracking_id'] == $data[$i + 1]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 2]['tracking_id'] &&
							$data[$i]['tracking_id'] == $data[$i + 3]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 4]['tracking_id'] &&
							$data[$i]['tracking_id'] == $data[$i + 5]['tracking_id']) {
							$totalItem_AX = $items_AW[$i + 1] + $items_AW[$i + 2] + $items_AW[$i + 3] + $items_AW[$i + 4] + $items_AW[$i + 5];
						} else if ($data[$i]['tracking_id'] == $data[$i + 1]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 2]['tracking_id'] &&
							$data[$i]['tracking_id'] == $data[$i + 3]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 4]['tracking_id']) {
							$totalItem_AX = $items_AW[$i + 1] + $items_AW[$i + 2] + $items_AW[$i + 3] + $items_AW[$i + 4];
						} else if ($data[$i]['tracking_id'] == $data[$i + 1]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 2]['tracking_id'] &&
							$data[$i]['tracking_id'] == $data[$i + 3]['tracking_id']) {
							$totalItem_AX = $items_AW[$i + 1] + $items_AW[$i + 2] + $items_AW[$i + 3];
						} else if ($data[$i]['tracking_id'] == $data[$i + 1]['tracking_id'] && $data[$i]['tracking_id'] == $data[$i + 2]['tracking_id']) {
							$totalItem_AX = $items_AW[$i + 1] + $items_AW[$i + 2];
						} else if ($data[$i + 1]['tracking_id'] == $data[$i]['tracking_id']) {
							$totalItem_AX = $data[$i]['items_AW'];
						}
					} else {
						$totalItem_AX = 0;
					}
					array_push($data, $totalItem_AX);
//					return dnp($totalItem_AX);
				}
//					} else {
//						$this->session->set_flashdata('danger', 'Import Failed! File format does not supported.');
//						redirect('home/index');
//					}
				if (ob_get_contents()) ob_end_clean();
				return dnp($data);
//				$this->admin->uploadOrder($data);
				$this->session->set_flashdata('success', 'File imported successfully.');
				redirect('admin/invoice');
			}
		}
	}


	function invoice()
	{
		$this->data['title'] = 'Invoice';
		$this->makeView('/invoice');
	}

	function getInvoice()
	{
		$action = '<a href="viewInvoice/$1" class="btn btn-primary">View Invoice</a>
			<a href="javascript:void(0);" onclick="loadPopup(\'' . base_url('admin/printInvoice/$1') . '\')" class="btn btn-info">Print</a>';
		$this->datatables->select('id, fileName, createAt, updateAt');
		$this->datatables->from(TABLE_INVOICE);
		$this->datatables->addColumn('actions', $action, 'id');
		$this->datatables->generate();
	}

	function viewInvoice($id)
	{
		$this->data['title'] = 'Invoice Details';
		$this->makeView('/viewInvoice');
	}

	function printInvoice($id)
	{
		$this->data['title'] = 'Print Invoice';
		$this->data['data'] = $this->admin->getImportedOrderByInvoiceId($id);
		$this->popupView('/printInvoice');
	}

	function getOrder()
	{
		$this->datatables->select('id, invoiceId, selro_order_id, order_id, order_date, expected_dispatch_date, 
			channel, channel_name, site, title, variation, asin, sku, upc, order_item_id, order_status, weight, 
			weight_unit, item_price, quantity_purchased, sub_total, shipping_cost, line_item_total, order_total, 
			buyer_email, buyer_name, ship_address_1, ship_address_2, ship_address_3, ship_city, ship_state, 
			ship_country, ship_country_code, ship_postalcode, shipping_discount, shipping_tax, item_tax, currency_code, 
			payment_status, payment_date, payments_transaction_id, shipped_date, shipping_method, shipping_carrier, 
			tel_no, tracking_id, ean, order_customisation, payment_method, minParcelPerSKU, maxParcel, parcel, L, W, postage, pfSurge,
			ofaCharge, postageCost, totalPostageCost, londonCon, fuelSurge, createAt');
		$this->datatables->from(TABLE_IMPORTORDERS);
		$this->datatables->generate();
	}

	function postCode()
	{
		$this->data['title'] = 'OFA Post Code';
		$this->makeView('/postCode');
	}

}
