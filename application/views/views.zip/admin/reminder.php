<div class="row">
	<div class="col-md-12">
		<div class="box box-info">
			<div class="box-header with-border">
				<h3 class="box-title"><b>Reminder List</b></h3>
				<a href="javascript:void(0);"
				   onclick="loadPopup('<?= admin_url('addReminder') ?>')"
				   class="btn btn-sm btn-info pull-right">Add New</a>
			</div>
			<div class="box-body">
				<div class="table-responsive">
					<table id="reportTable" class="table table-striped table-bordered serverSide-table dtr-inline text-bold text-center"
						   style="width: 100% !important;">
						<thead>
						<tr>
							<th>Name</th>
							<th style="padding: 10px 50px">Name</th>
							<th style="padding: 10px 50px">Phone</th>
							<th>Doctor name</th>
							<th>Service/Product name</th>
							<th style="padding: 10px 90px">Notes</th>
							<th>Town</th>
							<th>Referral</th>
							<th>Create By</th>
							<th>Create At</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
	table.dataTable tbody td {
		vertical-align: middle;
		padding-left: 0;
		padding-right: 0;
		margin-left: 0;
		margin-right: 0;
		margin-top: 0;
		margin-bottom: 0;
		padding-top: 0;
		padding-bottom: 0;
	}

	#reportTable {
		border-collapse: collapse;
	}
</style>
<script>
	var Table, selectedIDs = [];
	window.onload = function () {
		geTableData();
	};

	function geTableData() {
		Table = $('.serverSide-table').DataTable({
			serverSide: true,
			order: [[0, "ASC"]],
			// destroy: true,
			stateSave: true,
			"columnDefs": [
				{
					"render": function (data, type, row) {
						return moment(data).format('D MMM YYYY hh:mm:ss A');
					}, "targets": 9
				},
				{
					"render": function (data, type, row) {
						if (data == 1) {
							return '<span class="text-center">—</span>';
						} else {
							return '<a onclick="return confirm(\'Are you sure?\')" href="<?= admin_url('changeStatus/') ?>' + row['id'] + '" <button' +
								' class="btn btn-sm btn-danger">Send</button>';
						}
					}, "targets": 10
				}
			],
			'aoColumns': [{mData: "customerName"}, {mData: "phone"}, {mData: "email"}, {mData: "doctorName"}, {mData: "serviceName"},
				{mData: "note"}, {mData: "town"}, {mData: "referral"}, {mData: "name"},
				{mData: "createAt"}, {mData: "status"}, {
					mData: "actions", bSortable: false
				}],
			"aLengthMenu": [[25, 50, 100, 200, 500, 1000], [25, 50, 100, 200, 500, 1000]],
			"iDisplayLength": 25,
			'bProcessing': true,
			"language": {
				processing: '<div><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading Please Wait...</span></div>'
			},
			'bServerSide': true,
			'sAjaxSource': '<?= admin_url('getReminder') ?>',
			'fnServerData': function (sSource, aoData, fnCallback) {
				$.ajax({
					'dataType': 'json',
					'type': 'POST',
					'url': sSource,
					'data': aoData,
					'success': function (d, e, f) {
						console.log(d);
						fnCallback(d, e, f);
					},
					error: function (jqXHR, textStatus, errorThrown) {
						console.log(jqXHR);
						if (jqXHR.jqXHRstatusText)
							alert(jqXHR.jqXHRstatusText);
					}
				});
			},
			"fnFooterCallback": function (nRow, aaData, iStart, iEnd, aiDisplay) {
				// console.log(nRow);
			},
			"fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
				if (aData['status'] == 1) {
					$('td', nRow).css('color', 'red');
					$("td:eq(11)", nRow).text("—");
				}
			},
			select: {
				style: 'multi',
				selector: 'td:first-child'
			},
			dom: '<"top"B<"pull-right"f>>irtlp',
			// dom: 'lfrtip',
			buttons: [
				'copy', {
					extend: 'csv',
					exportOptions: {
						columns: ':visible:not(:last-child)'
					}
				}, {
					extend: 'excel',
					exportOptions: {
						columns: ':visible:not(:last-child)'
					}
				}, {
					extend: 'colvis',
					text: 'Column Visibility',
					collectionLayout: 'two-column'
				}
			]
		});
		// yadcf.init(Table, [
		// 	{column_number: 0, filter_default_label: "Type...", filter_type: "text"}
		// ], "header");
	}
</script>
