<div class="modal fade in" id="modal-default" style="display: block;overflow: auto; padding-left: 25px;">
	<div class="modal-dialog modal-lg" style="width: 90%">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="btn btn-danger pull-right" data-dismiss="modal" aria-label="Close">Close
				</button>
				<h4 class="modal-title"><b>Add New Reminder</b></h4>
			</div>
			<div class="modal-body">
				<form id="form" action="<?= admin_url('saveReminder') ?>" method="post" enctype="multipart/form-data">
					<div class="row">
						<div class="form-group col-md-4">
							<label for="customerId">Select Existing Customer</label><br>
							<select style="width: 100%" id="customerId" name="customerId"
									class="form-control selectCustomer"></select>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3">
							<label for="customerName"> Name <b class="text-danger">*</b></label>
							<input class="form-control" type="text" name="customerName" id="customerName"
								   placeholder="Enter Customer Name" required>
						</div>
						<div class="form-group col-md-3">
							<label for="phone"> Phone </label>
							<input class="form-control" type="text" name="phone" id="phone"
								   placeholder="Enter Phone Number">
						</div>
						<div class="form-group col-md-3">
							<label for="email"> Email </label>
							<input class="form-control" type="email" name="email" id="email"
								   placeholder="Enter Phone Number">
						</div>
						<div class="form-group col-md-3">
							<label for="doctorName">Doctor Name</label>
							<select style="width: 100%" id="doctorName" name="doctorName"
									class="form-control selectDoctor"></select>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3">
							<label for="serviceName">Service/Product Name</label>
							<select style="width: 100%" id="serviceName" name="serviceName"
									class="form-control selectService"></select>
						</div>
						<div class="form-group col-md-3">
							<label for="serviceName">Date<b class="text-danger">*</b></label>
							<div class="input-group date">
								<div class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</div>
								<input type="text" class="form-control pull-right" name="date"
									   id="date" placeholder="Select Date" required>
							</div>
						</div>
						<div class="form-group col-md-3">
							<label for="town">Town</label>
							<input class="form-control" type="text" name="town" id="town">
						</div>
						<div class="form-group col-md-3">
							<label for="referral">Referral </label>
							<input class="form-control" type="text" name="referral" id="referral">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-6">
							<label for="note">Note</label>
							<textarea class="form-control" name="note" id="note"></textarea>
						</div>
					</div>
					<div class="box-footer">
						<div class="row">
							<div class="form-group col-md-12">
								<button type="submit" class="btn btn-success pull-right">Save</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$('#date').datepicker({
		autoclose: true,
		todayHighlight: true,
		startDate: '0',
		format: 'dd M yyyy'
	});
	$(function () {
		function formatCustom(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		function selection(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.customerName;
			}
		}

		function formatCustomServie(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function selectionServicec(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.serviceName;
			}
		}

		function formatCustomDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		function selectionDoctor(data) {
			if (data.id === '') {
				return data.text;
			} else {
				return data.doctorName;
			}
		}

		$(".selectCustomer").select2({
			placeholder: "Select Old Customer",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustom,
			templateSelection: selection,
			ajax: {
				url: '<?= admin_url("getCustomerSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		}).on('select2:select', function (event) {
			var data = event.params.data;
			$('#customerName').val(data.customerName);
			$('#phone').val(data.phone);
			$('#email').val(data.email);
		});
		$(".selectService").select2({
			placeholder: "Select Service/Product",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustomServie,
			templateSelection: selectionServicec,
			ajax: {
				url: '<?= admin_url("getServiceSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		});
		$(".selectDoctor").select2({
			placeholder: "Select Doctor",
			dropdownParent: $('#remoteModal1'),
			templateResult: formatCustomDoctor,
			templateSelection: selectionDoctor,
			ajax: {
				url: '<?= admin_url("getDoctorSearch") ?>',
				dataType: 'json',
				type: "POST",
				quietMillis: 50,
				allowClear: true,
				data: function (params) {
					return {
						searchTerm: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				}
			}
		})
	});
</script>
